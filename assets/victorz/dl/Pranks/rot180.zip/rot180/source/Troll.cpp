// Troll.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Windows.h"

int _tmain(int argc, _TCHAR* argv[])
{
	HDC hdcScreen = CreateDC(TEXT("DISPLAY"), NULL, NULL, NULL);
	int scrW = GetDeviceCaps(hdcScreen, HORZRES);
	int scrH = GetDeviceCaps(hdcScreen, VERTRES);
	StretchBlt(hdcScreen, // dest DC
		0, // dest x
		0, // dest y
		scrW, // dest width
		scrH, // dest height
		hdcScreen, // source DC
		scrW, // source x
		scrH, // source y
		-scrW, // source width
		-scrH, // source height
		SRCCOPY // raster op
	);
}

